package carDealership;

public class IllegalCapacityException extends RuntimeException {

	private static final long serialVersionUID = 8128614141471165676L;

	public IllegalCapacityException() {
		super();
	}
}
